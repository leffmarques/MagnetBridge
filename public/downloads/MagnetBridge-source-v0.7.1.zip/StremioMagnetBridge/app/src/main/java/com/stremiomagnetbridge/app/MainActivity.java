package com.stremiomagnetbridge.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    // Matches 40-character hex SHA1 hash in URL path, query, or text
    private static final Pattern HASH_PATTERN = Pattern.compile("(?i)(?:^|/|urn:btih:|=)([a-f0-9]{40})(?:/|\\?|&|$)");
    private static final String DEFAULT_TRACKERS = 
        "&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce" +
        "&tr=udp%3A%2F%2Fopen.stealth.si%3A80%2Fannounce" +
        "&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce" +
        "&tr=udp%3A%2F%2Fexplodie.org%3A6969%2Fannounce";

    private String magnetUri;
    private String infoHash;
    private String rawReceivedUrl;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private void handle(Intent intent) {
        String urlString = null;
        if (intent != null) {
            Uri data = intent.getData();
            if (data != null) {
                urlString = data.toString();
            } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
                String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (shared != null) urlString = shared.trim();
            }
        }

        if (urlString != null && !urlString.isEmpty()) {
            processUrl(urlString, false);
        } else {
            showDashboard(null);
        }
    }

    private boolean processUrl(String input, boolean fromManualInput) {
        if (input == null || input.trim().isEmpty()) {
            if (fromManualInput) {
                Toast.makeText(this, "Please enter a valid Stremio streaming URL.", Toast.LENGTH_SHORT).show();
            } else {
                showDashboard(null);
            }
            return false;
        }

        input = input.trim();
        rawReceivedUrl = input;

        // Try extracting 40-hex infohash
        Matcher matcher = HASH_PATTERN.matcher(input);
        if (matcher.find()) {
            infoHash = matcher.group(1).toLowerCase();
            magnetUri = "magnet:?xt=urn:btih:" + infoHash + DEFAULT_TRACKERS;
            showTorrentScreen();
            return true;
        } else {
            String errorMsg = "Could not find a 40-character BitTorrent infohash in this URL.\nEnsure Stremio streaming server is using torrent streams.";
            if (fromManualInput) {
                Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show();
            } else {
                showDashboard(errorMsg);
            }
            return false;
        }
    }

    private GradientDrawable createCardBg(int color, int radiusDp, int strokeColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) {
            gd.setStroke(dp(1), strokeColor);
        }
        return gd;
    }

    private void showTorrentScreen() {
        int bg = Color.rgb(10, 13, 30);
        int cardBg = Color.rgb(20, 25, 50);
        int white = Color.rgb(245, 246, 255);
        int muted = Color.rgb(166, 174, 207);
        int accent = Color.rgb(147, 51, 234);
        int success = Color.rgb(34, 197, 94);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));
        page.setBackgroundColor(bg);

        // Header / Brand
        TextView brand = new TextView(this);
        brand.setText("MAGNET BRIDGE 0.7.1");
        brand.setTextColor(Color.rgb(192, 132, 252));
        brand.setTextSize(12);
        brand.setLetterSpacing(0.12f);
        brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);

        // Title
        TextView title = new TextView(this);
        title.setText("Torrent Identified!");
        title.setTextColor(white);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(8);
        page.addView(title, titleLp);

        // Subtitle
        TextView subtitle = new TextView(this);
        subtitle.setText("Stremio stream link was successfully converted into a BitTorrent magnet link.");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(13);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(4);
        page.addView(subtitle, subLp);

        // InfoHash Card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(createCardBg(cardBg, 12, Color.rgb(45, 55, 95)));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.topMargin = dp(20);
        page.addView(card, cardLp);

        TextView badge = new TextView(this);
        badge.setText("● INFOHASH DETECTED (SHA1 v1)");
        badge.setTextColor(success);
        badge.setTextSize(11);
        badge.setTypeface(null, Typeface.BOLD);
        card.addView(badge);

        TextView hashText = new TextView(this);
        hashText.setText(infoHash);
        hashText.setTextColor(white);
        hashText.setTextSize(14);
        hashText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hashText.setTextIsSelectable(true);
        LinearLayout.LayoutParams hashLp = new LinearLayout.LayoutParams(-1, -2);
        hashLp.topMargin = dp(8);
        card.addView(hashText, hashLp);

        if (rawReceivedUrl != null) {
            TextView sourceLabel = new TextView(this);
            sourceLabel.setText("STREAM SOURCE URL:");
            sourceLabel.setTextColor(muted);
            sourceLabel.setTextSize(10);
            sourceLabel.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams srcLblLp = new LinearLayout.LayoutParams(-1, -2);
            srcLblLp.topMargin = dp(12);
            card.addView(sourceLabel, srcLblLp);

            TextView sourceText = new TextView(this);
            sourceText.setText(rawReceivedUrl);
            sourceText.setTextColor(Color.rgb(180, 190, 220));
            sourceText.setTextSize(11);
            sourceText.setTypeface(Typeface.MONOSPACE);
            sourceText.setTextIsSelectable(true);
            LinearLayout.LayoutParams srcLp = new LinearLayout.LayoutParams(-1, -2);
            srcLp.topMargin = dp(4);
            card.addView(sourceText, srcLp);
        }

        // Action Buttons
        Button openBtn = new Button(this);
        openBtn.setText("OPEN MAGNET IN TORRENT APP");
        openBtn.setAllCaps(false);
        openBtn.setTextColor(Color.WHITE);
        openBtn.setTextSize(14);
        openBtn.setTypeface(null, Typeface.BOLD);
        openBtn.setBackground(createCardBg(accent, 10, 0));
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(-1, dp(48));
        openLp.topMargin = dp(20);
        page.addView(openBtn, openLp);
        openBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMagnetInClient();
            }
        });

        Button copyBtn = new Button(this);
        copyBtn.setText("COPY MAGNET LINK TO CLIPBOARD");
        copyBtn.setAllCaps(false);
        copyBtn.setTextColor(white);
        copyBtn.setTextSize(14);
        copyBtn.setBackground(createCardBg(Color.rgb(35, 42, 75), 10, Color.rgb(60, 70, 110)));
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(-1, dp(46));
        copyLp.topMargin = dp(10);
        page.addView(copyBtn, copyLp);
        copyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyMagnetToClipboard();
            }
        });

        Button shareBtn = new Button(this);
        shareBtn.setText("SHARE MAGNET LINK");
        shareBtn.setAllCaps(false);
        shareBtn.setTextColor(muted);
        shareBtn.setTextSize(13);
        shareBtn.setBackground(createCardBg(Color.TRANSPARENT, 10, Color.rgb(45, 55, 95)));
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(-1, dp(44));
        shareLp.topMargin = dp(10);
        page.addView(shareBtn, shareLp);
        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareMagnet();
            }
        });

        Button manualBtn = new Button(this);
        manualBtn.setText("PASTE ANOTHER STREAM URL");
        manualBtn.setAllCaps(false);
        manualBtn.setTextColor(Color.rgb(180, 190, 225));
        manualBtn.setTextSize(12);
        manualBtn.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams manualLp = new LinearLayout.LayoutParams(-1, -2);
        manualLp.topMargin = dp(14);
        page.addView(manualBtn, manualLp);
        manualBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDashboard(null);
            }
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void showDashboard(String errorMessage) {
        int bg = Color.rgb(10, 13, 30);
        int cardBg = Color.rgb(20, 25, 50);
        int white = Color.rgb(245, 246, 255);
        int muted = Color.rgb(166, 174, 207);
        int accent = Color.rgb(147, 51, 234);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));
        page.setBackgroundColor(bg);

        TextView brand = new TextView(this);
        brand.setText("MAGNET BRIDGE 0.7.1");
        brand.setTextColor(Color.rgb(192, 132, 252));
        brand.setTextSize(12);
        brand.setLetterSpacing(0.12f);
        brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);

        TextView title = new TextView(this);
        title.setText("Stremio External Player Bridge");
        title.setTextColor(white);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(8);
        page.addView(title, titleLp);

        TextView subtitle = new TextView(this);
        subtitle.setText("Integrates Stremio with external torrent clients (LibreTorrent, Flud, qBittorrent, etc).");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(13);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(4);
        page.addView(subtitle, subLp);

        if (errorMessage != null) {
            TextView errBox = new TextView(this);
            errBox.setText(errorMessage);
            errBox.setTextColor(Color.rgb(248, 113, 113));
            errBox.setTextSize(12);
            errBox.setPadding(dp(12), dp(12), dp(12), dp(12));
            errBox.setBackground(createCardBg(Color.rgb(45, 20, 25), 8, Color.rgb(120, 30, 40)));
            LinearLayout.LayoutParams errLp = new LinearLayout.LayoutParams(-1, -2);
            errLp.topMargin = dp(16);
            page.addView(errBox, errLp);
        }

        // How to use Card
        LinearLayout instructionsCard = new LinearLayout(this);
        instructionsCard.setOrientation(LinearLayout.VERTICAL);
        instructionsCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        instructionsCard.setBackground(createCardBg(cardBg, 12, Color.rgb(45, 55, 95)));
        LinearLayout.LayoutParams instLp = new LinearLayout.LayoutParams(-1, -2);
        instLp.topMargin = dp(20);
        page.addView(instructionsCard, instLp);

        TextView instTitle = new TextView(this);
        instTitle.setText("HOW IT WORKS IN STREMIO:");
        instTitle.setTextColor(Color.rgb(180, 150, 255));
        instTitle.setTextSize(12);
        instTitle.setTypeface(null, Typeface.BOLD);
        instructionsCard.addView(instTitle);

        TextView steps = new TextView(this);
        steps.setText(
            "1. Open Stremio on this device\n" +
            "2. Start playing any torrent movie / series\n" +
            "3. Tap the video player options (3 dots) > 'Play in external player'\n" +
            "4. Choose 'Magnet Bridge'\n" +
            "5. Magnet Bridge catches the stream URL and opens your torrent app!"
        );
        steps.setTextColor(Color.rgb(215, 222, 245));
        steps.setTextSize(13);
        steps.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams stepLp = new LinearLayout.LayoutParams(-1, -2);
        stepLp.topMargin = dp(10);
        instructionsCard.addView(steps, stepLp);

        // Manual Input Area
        TextView manualLabel = new TextView(this);
        manualLabel.setText("TEST OR PASTE A STREAM LINK MANUALLY:");
        manualLabel.setTextColor(muted);
        manualLabel.setTextSize(11);
        manualLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams mLblLp = new LinearLayout.LayoutParams(-1, -2);
        mLblLp.topMargin = dp(24);
        page.addView(manualLabel, mLblLp);

        final EditText urlInput = new EditText(this);
        urlInput.setHint("http://127.0.0.1:11470/4f50.../0");
        urlInput.setHintTextColor(Color.rgb(100, 110, 140));
        urlInput.setTextColor(white);
        urlInput.setTextSize(13);
        urlInput.setTypeface(Typeface.MONOSPACE);
        urlInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        urlInput.setBackground(createCardBg(cardBg, 8, Color.rgb(60, 70, 110)));
        LinearLayout.LayoutParams inpLp = new LinearLayout.LayoutParams(-1, -2);
        inpLp.topMargin = dp(8);
        page.addView(urlInput, inpLp);

        Button convertBtn = new Button(this);
        convertBtn.setText("CONVERT TO MAGNET LINK");
        convertBtn.setAllCaps(false);
        convertBtn.setTextColor(Color.WHITE);
        convertBtn.setTextSize(14);
        convertBtn.setTypeface(null, Typeface.BOLD);
        convertBtn.setBackground(createCardBg(accent, 8, 0));
        LinearLayout.LayoutParams convLp = new LinearLayout.LayoutParams(-1, dp(46));
        convLp.topMargin = dp(12);
        page.addView(convertBtn, convLp);
        convertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processUrl(urlInput.getText().toString(), true);
            }
        });

        // Sample Test button
        Button sampleBtn = new Button(this);
        sampleBtn.setText("Paste Sample Stremio URL");
        sampleBtn.setAllCaps(false);
        sampleBtn.setTextColor(Color.rgb(180, 190, 225));
        sampleBtn.setTextSize(12);
        sampleBtn.setBackgroundColor(Color.TRANSPARENT);
        page.addView(sampleBtn);
        sampleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                urlInput.setText("http://127.0.0.1:11470/b8e018d963ca612e4d0d0f04c63673510e82cbf3/0");
            }
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void openMagnetInClient() {
        if (magnetUri == null) return;
        try {
            Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(magnetUri));
            open.addCategory(Intent.CATEGORY_BROWSABLE);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent chooser = Intent.createChooser(open, "Open magnet link with torrent client");
            chooser.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(this, "No compatible torrent client found on device.\nPlease install LibreTorrent, Flud, or BiglyBT.", Toast.LENGTH_LONG).show();
        }
    }

    private void copyMagnetToClipboard() {
        if (magnetUri == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("BitTorrent Magnet Link", magnetUri);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Magnet link copied to clipboard!", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareMagnet() {
        if (magnetUri == null) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, magnetUri);
        share.putExtra(Intent.EXTRA_SUBJECT, "BitTorrent Magnet Link (" + infoHash + ")");
        try {
            startActivity(Intent.createChooser(share, "Share magnet link via"));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to share magnet link.", Toast.LENGTH_SHORT).show();
        }
    }
}
