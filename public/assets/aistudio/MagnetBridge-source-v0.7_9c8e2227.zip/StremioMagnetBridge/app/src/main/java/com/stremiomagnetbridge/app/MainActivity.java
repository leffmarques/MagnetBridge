package com.stremiomagnetbridge.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final Pattern HASH_IN_PATH = Pattern.compile("^/([a-fA-F0-9]{40})(?:/|$)");
    private String magnetUri;
    private String infoHash;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private void handle(Intent intent) {
        Uri source = intent == null ? null : intent.getData();
        if (source == null && intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) source = Uri.parse(shared.trim());
        }

        if (source == null || !"http".equalsIgnoreCase(source.getScheme())
                || !"127.0.0.1".equalsIgnoreCase(source.getHost()) || source.getPort() != 11470) {
            showError("No Stremio stream URL was received. Open Magnet Bridge from Stremio's external player list.");
            return;
        }

        Matcher matcher = HASH_IN_PATH.matcher(source.getPath() == null ? "" : source.getPath());
        if (!matcher.find()) {
            showError("Could not find a 40-character BitTorrent v1 infohash in this URL.");
            return;
        }

        infoHash = matcher.group(1).toLowerCase();
        magnetUri = "magnet:?xt=urn:btih:" + infoHash;
        showHome();
    }

    private void showHome() {
        int bg = Color.rgb(10, 13, 38);
        int panel = Color.rgb(24, 29, 62);
        int white = Color.rgb(245, 246, 255);
        int muted = Color.rgb(166, 174, 207);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(bg);

        TextView brand = new TextView(this);
        brand.setText("MAGNET BRIDGE");
        brand.setTextColor(Color.rgb(180, 150, 255));
        brand.setTextSize(13);
        brand.setLetterSpacing(0.14f);
        brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);

        TextView title = new TextView(this);
        title.setText("Torrent detected");
        title.setTextColor(white);
        title.setTextSize(27);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(12);
        page.addView(title, titleLp);

        TextView subtitle = new TextView(this);
        subtitle.setText("The Stremio stream link was converted into a BitTorrent infohash.");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(7);
        page.addView(subtitle, subLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(panel);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.topMargin = dp(24);
        page.addView(card, cardLp);

        TextView status = new TextView(this);
        status.setText("INFOHASH IDENTIFIED");
        status.setTextColor(Color.rgb(111, 224, 174));
        status.setTextSize(11);
        status.setTypeface(null, Typeface.BOLD);
        card.addView(status);

        TextView hash = new TextView(this);
        hash.setText(infoHash);
        hash.setTextColor(white);
        hash.setTextSize(13);
        hash.setTextIsSelectable(true);
        LinearLayout.LayoutParams hashLp = new LinearLayout.LayoutParams(-1, -2);
        hashLp.topMargin = dp(10);
        card.addView(hash, hashLp);

        TextView metadataTitle = new TextView(this);
        metadataTitle.setText("Torrent metadata");
        metadataTitle.setTextColor(white);
        metadataTitle.setTextSize(18);
        metadataTitle.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams mtLp = new LinearLayout.LayoutParams(-1, -2);
        mtLp.topMargin = dp(24);
        page.addView(metadataTitle, mtLp);

        TextView metadata = new TextView(this);
        metadata.setText("Metadata lookup engine is the next integration step. Once connected, this area will show the torrent name, total size, file list, piece information and tracker details.");
        metadata.setTextColor(muted);
        metadata.setTextSize(14);
        metadata.setPadding(dp(16), dp(16), dp(16), dp(16));
        metadata.setBackgroundColor(panel);
        LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
        metaLp.topMargin = dp(10);
        page.addView(metadata, metaLp);

        Button openMagnet = new Button(this);
        openMagnet.setText("OPEN MAGNET LINK WITH TORRENT CLIENT");
        openMagnet.setAllCaps(false);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(-1, -2);
        openLp.topMargin = dp(24);
        page.addView(openMagnet, openLp);
        openMagnet.setOnClickListener(v -> openMagnet());

        Button saveTorrent = new Button(this);
        saveTorrent.setText("SAVE .TORRENT FILE");
        saveTorrent.setAllCaps(false);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-1, -2);
        saveLp.topMargin = dp(10);
        page.addView(saveTorrent, saveLp);
        saveTorrent.setOnClickListener(v ->
            Toast.makeText(this, "Torrent metadata lookup is not available in this build yet.", Toast.LENGTH_LONG).show()
        );

        TextView footer = new TextView(this);
        footer.setText("MAGNET BRIDGE 0.7 · METADATA ENGINE IN PROGRESS");
        footer.setTextColor(muted);
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(24);
        page.addView(footer, footLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void openMagnet() {
        Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(magnetUri));
        try {
            startActivity(Intent.createChooser(open, "Open magnet link with torrent client"));
        } catch (Exception e) {
            Toast.makeText(this, "No compatible torrent client was found.", Toast.LENGTH_LONG).show();
        }
    }

    private void showError(String message) {
        TextView view = new TextView(this);
        view.setText(message);
        view.setTextColor(Color.WHITE);
        view.setTextSize(16);
        view.setPadding(dp(24), dp(40), dp(24), dp(24));
        view.setBackgroundColor(Color.rgb(10, 13, 38));
        setContentView(view);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
